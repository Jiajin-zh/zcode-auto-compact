/* zcode-auto-compact 渲染层：在「上下文容量」弹窗里注入自动压缩阈值分区。
 * 标题行直接克隆原生标题行 DOM（样式与「上下文容量」完全一致）；滑块与原生
 * 进度条同视觉重量。改动即时写入配置（经主进程），运行中的引擎每次判定都会
 * 重读该值——即改即生效，全部会话生效。
 * 带版本守卫：主进程每 15 秒重放本脚本，版本号变化时先清掉旧实例再重装。 */
(function () {
  var VER = 6;
  if (window.__accVer === VER) return;
  if (window.__accCleanup) { try { window.__accCleanup(); } catch (e) { } }
  window.__accVer = VER;
  var P = 70;
  var HC = '[data-slot="hover-card-content"]';
  var ROW = "acc-ac-sec";
  var MIN = 10, MAX = 95;
  var cleanups = [];
  window.__accCleanup = function () {
    cleanups.forEach(function (f) { try { f(); } catch (e) { } });
    try {
      var rows = document.querySelectorAll("." + ROW);
      for (var i = 0; i < rows.length; i++) rows[i].remove();
    } catch (e) { }
  };

  function send(path, p) {
    try {
      fetch("https://acc-inject.local" + path + (p === undefined ? "" : "?p=" + p),
        { mode: "no-cors" }).catch(function () { });
    } catch (e) { }
  }
  var diagSeen = {};
  function diag(reason, extra) {
    var key = reason + "|" + String(extra || "");
    var now = Date.now();
    if (diagSeen[key] && now - diagSeen[key] < 60000) return;
    diagSeen[key] = now;
    send("/diag?r=" + encodeURIComponent(reason) + "&x=" + encodeURIComponent(String(extra || "").slice(0, 400)));
  }
  window.__accSet = function (p) { P = p; paint(); send("/set", p); };
  window.__accUpdate = function (p) { P = p; paint(); };
  window.__accInit = function (p) { P = p; scan(); };

  /* 样式：滑块与原生进度条同重量（8px 轨道 / 16px 拇指），只作用于本分区 */
  var STYLE_ID = "acc-ac-style";
  var ACC = "var(--color-primary, var(--primary, #3370ff))";
  function ensureStyle() {
    var st = document.getElementById(STYLE_ID);
    if (st) return;
    st = document.createElement("style");
    st.id = STYLE_ID;
    st.textContent = ""
      + ".acc-ac-range{-webkit-appearance:none;appearance:none;width:100%;height:8px;"
      + "border-radius:9999px;background:rgba(128,128,128,.22);outline:none;margin:8px 0 0;cursor:pointer;}"
      + ".acc-ac-range::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:16px;height:16px;"
      + "border-radius:50%;background:#fff;border:2px solid " + ACC + ";"
      + "box-shadow:0 1px 4px rgba(0,0,0,.35);transition:transform .12s ease,box-shadow .12s ease;}"
      + ".acc-ac-range:hover::-webkit-slider-thumb{transform:scale(1.1);box-shadow:0 2px 6px rgba(0,0,0,.4);}"
      + ".acc-ac-range:active::-webkit-slider-thumb{transform:scale(1.18);}";
    document.head.appendChild(st);
    cleanups.push(function () { try { st.remove(); } catch (e) { } });
  }

  var slider = null, valEl = null;

  function nativeHeaderRow(card) {
    /* 找原生标题行（flex … justify-between）：优先含「上下文容量」文本的那行 */
    var rows = [];
    try {
      var all = card.querySelectorAll("div");
      for (var i = 0; i < all.length; i++) {
        var cn = String(all[i].className || "");
        if (cn.indexOf("justify-between") >= 0 && all[i].children.length >= 2) rows.push(all[i]);
      }
    } catch (e) { }
    for (var j = 0; j < rows.length; j++) {
      if (rows[j].textContent.indexOf("上下文容量") >= 0) return rows[j];
    }
    return rows[0] || null;
  }
  function buildHeader(card) {
    var src = nativeHeaderRow(card);
    if (src) {
      try {
        var row = src.cloneNode(true);
        row.removeAttribute("id");
        var ids = row.querySelectorAll("[id]");
        for (var k = 0; k < ids.length; k++) ids[k].removeAttribute("id");
        /* 本分区位于卡片顶部：剥掉克隆行自带的上边框与顶部内/外边距（原生里它属于第二分区） */
        try {
          var kill = [];
          for (var bi = 0; bi < row.classList.length; bi++) {
            if (/^border(-|$)/.test(row.classList[bi]) || /^(pt|py|mt|my|m)(-|$)/.test(row.classList[bi])) {
              kill.push(row.classList[bi]);
            }
          }
          for (var bj = 0; bj < kill.length; bj++) row.classList.remove(kill[bj]);
          row.style.borderTop = "none";
          row.style.paddingTop = "0";
          row.style.marginTop = "0";
        } catch (e) { }
        /* 两端子节点 = 标题 与 标值：只保留这两个，改写文字 */
        var kids = [];
        for (var c = 0; c < row.children.length; c++) kids.push(row.children[c]);
        while (row.children.length > 2) row.removeChild(row.children[1]);   // 只留两端：标题与标值
        var lab = row.children[0], val = row.children[row.children.length - 1];
        lab.textContent = "自动压缩阈值";
        val.textContent = P + "%";
        valEl = val;
        diag("header-cloned", String(src.className || "").slice(0, 120));
        return row;
      } catch (e) { diag("header-clone-failed", String(e).slice(0, 100)); }
    }
    /* 兜底：用已确认存在的原生类组合 */
    var fb = document.createElement("div");
    fb.className = "flex items-center justify-between gap-3 text-ui-sm";
    var l = document.createElement("span");
    l.textContent = "自动压缩阈值";
    l.style.cssText = "opacity:.62;";
    valEl = document.createElement("span");
    valEl.textContent = P + "%";
    valEl.style.cssText = "font-weight:600;font-variant-numeric:tabular-nums;";
    fb.appendChild(l);
    fb.appendChild(valEl);
    return fb;
  }
  function paint() {
    if (valEl && valEl.textContent !== P + "%") valEl.textContent = P + "%";
    if (slider) {
      var pct = (P - MIN) * 100 / (MAX - MIN);
      slider.style.background = "linear-gradient(to right," + ACC + " " + pct + "%,rgba(128,128,128,.22) " + pct + "%)";
    }
  }
  function build(card) {
    ensureStyle();
    var sec = document.createElement("div");
    sec.className = ROW;
    sec.appendChild(buildHeader(card));
    slider = document.createElement("input");
    slider.type = "range";
    slider.min = String(MIN);
    slider.max = String(MAX);
    slider.step = "1";
    slider.value = String(P);
    slider.className = "acc-ac-range";
    slider.setAttribute("aria-label", "自动压缩阈值百分比");
    var timer = null;
    slider.addEventListener("input", function () {
      P = Number(slider.value);
      paint();
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () { window.__accSet(P); }, 250);   // 拖动停顿再落盘
    });
    sec.appendChild(slider);
    paint();
    return sec;
  }
  function clsOf(el) { try { return String(el.className || "").slice(0, 100); } catch (e) { return ""; } }
  function scan() {
    var cards;
    try { cards = document.querySelectorAll(HC); } catch (e) { return; }
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i];
      var cls = c.classList;
      if (!cls || !cls.contains("!w-80")) { diag("hc-no-w80", clsOf(c)); continue; }
      if (!c.querySelector('[data-slot="progress"]')) { diag("hc-no-progress", clsOf(c)); continue; }
      var body = c.querySelector("div.space-y-3");
      if (!body) { diag("hc-no-body", clsOf(c)); continue; }
      if (body.querySelector("." + ROW)) { paint(); continue; }
      body.insertBefore(build(c), body.firstChild);
      send("/attach");
    }
  }
  scan();
  try {
    var obs = new MutationObserver(function () { setTimeout(scan, 50); });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    cleanups.push(function () { try { obs.disconnect(); } catch (e) { } });
  } catch (e) { }
  var iv = setInterval(scan, 2000);
  cleanups.push(function () { clearInterval(iv); });
})();
